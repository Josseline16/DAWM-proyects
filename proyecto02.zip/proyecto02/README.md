# PROYECTO 02
## OBJETIVO
Este proyecto se realiza con el fin de implementar una página web interactiva que use las tecnologías disponibles del lado del cliente.
## IMPLEMENTACIÓN
La página web consiste en una dashboard que usa una fuente de datos externa parametrizando las diferentes métricas.
